import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'

@Component({
  selector: 'app-searchuser',
  templateUrl: './searchuser.component.html',
  styleUrls: ['./searchuser.component.css']
})
export class SearchuserComponent implements OnInit {
  array = data
  flag = false
  constructor() { }

  ngOnInit() {
  }

  setFlag() {
    this.flag = true
  }
}
